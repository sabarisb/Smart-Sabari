package com.demo.service;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.dao.CustomerDAO;
import com.demo.entity.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {
	// need to inject customer dao
	@Autowired
	private CustomerDAO customerDAO;

	@Override
	@Transactional
	public double getCustomers() {
		 double Emi(double loan_amount,double rate_of_interest,double tenure,double no_of_years)
			{
				

				double Y,T,S,I;
				double emi;
				rate_of_interest=rate_of_interest/100;
				
				I=rate_of_interest/no_of_years;
				Y=1+I;
				T=Math.pow(Y, tenure);
				S=1/T;
				emi=(loan_amount*I)/(1-S);
				return emi;
			}
		
		return customerDAO.getCustomers();
	}

	@Override
	@Transactional
	public void saveCustomer(Customer theCustomer) {
		
		void repaymentschedule(double emiamount,double principle,double interest,double tenure,double numofyears)
		{
			int installmentno;
			//OPn =Outstanding Principal at the beginning of the nth Installment period;
			double opn[]=new double[100];
			//Pn = Principal component of the nth installment
			double pn[]=new double[100]; 
			//In = Interest component of the nth Installment
			double in[]=new double[100];
			opn[1]=principle;
		
			for(installmentno=1;installmentno<=numofyears;installmentno++)
			{
				 
				in[installmentno]=(double)Math.round((opn[installmentno]*(interest/(1200)))*100/100);
				pn[installmentno]=(double)Math.round(((emiamount-in[installmentno])*100)/100);
				opn[installmentno+1]=(double)Math.round(((opn[installmentno]-pn[installmentno])*100)/100);
				System.out.println(installmentno +"   "+(in[installmentno])+"  " + (pn[installmentno]) + "  " +opn[installmentno]);
		}
		Scanner scanner=new Scanner(System.in);
		//System.out.println("enter the no of installments");
	int output=scanner.nextInt();
	int g=output;
	if(g==output)
	{
		System.out.println(g);
		System.out.println(in[g]);
		System.out.println(pn[g]);
		System.out.println(opn[g]);
	}

			}

		customerDAO.saveCustomer(theCustomer);
	}

	@Override
	@Transactional
	public Customer getCustomer(int theId) {

		return customerDAO.getCustomer(theId);
	}

//	@Override
//	@Transactional
//	public void deleteCustomer(int theId) {
//
//		customerDAO.deleteCustomer(theId);
//	}
}
