package com.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "emi_login")
public class User {
	@Id
	@Column(name = "principal")
	private String principal;

	@Column(name = "interest")
	private String interest;
	
	@Column(name = "tenure")
	private String tenure;
	
	@Column(name = "noofyears")
	private String noofyears;


	public User() {

	}


	public String getPrincipal() {
		return principal;
	}


	public void setPrincipal(String principal) {
		this.principal = principal;
	}


	public String getInterest() {
		return interest;
	}


	public void setInterest(String interest) {
		this.interest = interest;
	}


	public String getTenure() {
		return tenure;
	}


	public void setTenure(String tenure) {
		this.tenure = tenure;
	}


	public String getNoofyears() {
		return noofyears;
	}


	public void setNoofyears(String noofyears) {
		this.noofyears = noofyears;
	}

}
