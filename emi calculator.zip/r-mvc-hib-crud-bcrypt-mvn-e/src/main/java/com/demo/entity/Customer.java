package com.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	
	@Column(name="loan_amount")
	private String loan_amount;
	
	@Column(name="rate_of_interest")
	private String rate_of_interest;
	
	@Column(name="tenure")
	private String tenure;

	@Column(name="no_of_years")
	private String no_of_years;
	
	public Customer() {
		
	}

	

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getLoan_amount() {
		return loan_amount;
	}



	public void setLoan_amount(String loan_amount) {
		this.loan_amount = loan_amount;
	}



	public String getRate_of_interest() {
		return rate_of_interest;
	}



	public void setRate_of_interest(String rate_of_interest) {
		this.rate_of_interest = rate_of_interest;
	}



	public String getTenure() {
		return tenure;
	}



	public void setTenure(String tenure) {
		this.tenure = tenure;
	}



	public String getNo_of_years() {
		return no_of_years;
	}



	public void setNo_of_years(String no_of_years) {
		this.no_of_years = no_of_years;
	}



	@Override
	public String toString() {
		return "Customer [id=" + id + ", loan_amount=" + loan_amount + ", rate_of_interest=" + rate_of_interest + ", tenure=" + tenure + ", no_of_years=" + no_of_years + "]";
	}
		
}





